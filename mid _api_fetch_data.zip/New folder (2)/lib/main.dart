import 'package:flutter/material.dart';
import 'show_grade_page.dart'; // Create this as your page file

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ShowGradePage(),
  ));
}
