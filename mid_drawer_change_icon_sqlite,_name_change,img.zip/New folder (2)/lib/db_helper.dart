import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static Database? _database;
  static const String _tableName = 'records';
  static const String _columnId = 'id';
  static const String _columnText = 'text';

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'app_database.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  void _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE $_tableName(
      $_columnId INTEGER PRIMARY KEY AUTOINCREMENT,
      $_columnText TEXT
    )''');
  }

  Future<int> insertRecord(String text) async {
    final db = await database;
    return await db.insert(_tableName, { _columnText: text });
  }

  Future<List<Map<String, dynamic>>> getRecords() async {
    final db = await database;
    return await db.query(_tableName);
  }

  Future<int> deleteRecord(int id) async {
    final db = await database;
    return await db.delete(_tableName, where: '$_columnId = ?', whereArgs: [id]);
  }
}
