import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  final List<Map<String, dynamic>> subjects = [
    {'name': 'Mobile Development', 'teacher': 'Nabeel Sahib', 'credit': 3},
    {'name': 'AI', 'teacher': 'Shahzad Sahib', 'credit': 4},
    {'name': 'Compiler Construction', 'teacher': 'Hassan Sahib', 'credit': 3},
    {'name': 'Islamyat', 'teacher': 'Farooq Sahib', 'credit': 1},
    {'name': 'Information Security', 'teacher': 'Mam Kashifa', 'credit': 3},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Text(
                'Menu',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              title: Text('Home'),
              onTap: () {
                Navigator.pop(context); // just close drawer if already on Home
              },
            ),
            ListTile(
              title: Text('Records'),
              onTap: () {
                Navigator.pushNamed(context, '/records');
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 16),
          Image.asset('assets/img.jpg', height: 150),

          SizedBox(height: 16),
          Text(
            'Enrolled Subjects',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                final sub = subjects[index];
                return ListTile(
                  title: Text(sub['name']),
                  subtitle: Text('Teacher: ${sub['teacher']}'),
                  trailing: Text('Credits: ${sub['credit']}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
