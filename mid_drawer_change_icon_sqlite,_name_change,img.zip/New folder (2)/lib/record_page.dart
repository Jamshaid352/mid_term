import 'package:flutter/material.dart';
import 'db_helper.dart';

class RecordPage extends StatefulWidget {
  @override
  _RecordPageState createState() => _RecordPageState();
}

class _RecordPageState extends State<RecordPage> {
  final TextEditingController _controller = TextEditingController();
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> _records = [];

  @override
  void initState() {
    super.initState();
    _loadRecords();
  }

  _loadRecords() async {
    final records = await _dbHelper.getRecords();
    setState(() {
      _records = records;
    });
  }

  _insertRecord() async {
    if (_controller.text.isNotEmpty) {
      await _dbHelper.insertRecord(_controller.text);
      _controller.clear();
      _loadRecords();
    }
  }

  _deleteRecord(int id) async {
    await _dbHelper.deleteRecord(id);
    _loadRecords();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SQLite Records')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: 'Enter Text'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _insertRecord,
              child: Text('Submit'),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _records.length,
                itemBuilder: (context, index) {
                  final record = _records[index];
                  return ListTile(
                    title: Text(record['text']),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () => _deleteRecord(record['id']),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
